package com.example.mindustry_studio
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun 切角按钮(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: CutCornerShape = CutCornerShape(8.dp),
    背景色: Color = Color.White,
    字体色: Color = Color.DarkGray,
    content: @Composable () -> Unit = { Text("按下按钮", color = 字体色) }
) {
    Box(
        modifier = modifier
            .size(150.dp, 50.dp)
            .background(背景色, shape = shape)
            .shadow(elevation = 2.dp, shape = shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}
@Preview(showBackground = true)
@Composable
fun Preview(){
    切角按钮(onClick = {})
}