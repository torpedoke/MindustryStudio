package com.example.mindustry_studio
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mindustry_studio.ui.theme.Mindustry设计器Theme
import com.example.mindustry_studio.ui.theme.蔚蓝色
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import org.json.JSONObject
import java.io.File


val Mod文件夹:File=File(// 外部存储目录+"/Mod文件夹"
    Environment.getExternalStorageDirectory(), "/Mod文件夹")
var 代码表:JSONObject = JSONObject()

// 设置 标志位, 用这个标识可以把特定情况区分开来
var 刚从权限设置里面回来 = false

// MainActivity 为 程序的入口/ 主行动
class MainActivity : ComponentActivity() {

    // onCreate 初始事件, Activity生命周期中 第一次被创建时调用的方法, 适合用于设置布局, 绑定组件和恢复状态.
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 允许内容延伸到系统 UI 下方
        enableEdgeToEdge()
        // 设置状态栏颜色
        代码表 = 读取内部json文件(this, "代码表.json")?.let { JSONObject(it) }!!// 绝对不是null的意思!
        setContent {//setContent(绘制函数).
                // 是否有访问所有文件的权限
                if (Environment.isExternalStorageManager()) {
                    // 有权限, 继续执行操作
                    主界面()
                } else {//没权限, 申请权限
                    权限申请页面()
                }
        }
    }
    /*  重新回到程序时调用/程序重新获得焦点时 调用,但是初始进入时 焦点也是从无到有, 所以第一次进入也会触发... ...
    * 所以最好用标志位变量的方法区分一下*/
    // onResume 获得焦点事件, 应用焦点从无到有时触发, 初始进入应用也算作一次, 需要区分情况.
    override fun onResume() {
        super.onResume()
        // 通过标志位确认是权限设置回来的后, 检查权限是否已经被开启
        if (刚从权限设置里面回来) {
            // 是否有访问所有文件的权限
            if (Environment.isExternalStorageManager()) {
                // 权限已开启，继续执行操作
                toast(this,"成功!")
                setContent {//setContent(绘制函数).
                        主界面() }
            } else {
                // 权限仍未开启，提示用户并优雅退出
                toast(this,"呜, 无法处理文件唉")
                finishAffinity()
            }
            刚从权限设置里面回来 = false// 重置标志位
        }

    }

}
@Composable
fun 权限申请页面() {
    /*返回最近的 CompositionLocalProvider 组件提供的值。直接或间接调用使用此代码的可组合函数的组件提供的值*/
    val context = LocalContext.current
    // 检查权限是否已经被授予
    val 有外部存储权限 = remember { mutableStateOf(Environment.isExternalStorageManager()) }
    if (有外部存储权限.value) {// 有权限,执行后续代码
        Log输出( "已授权")
    } else {
        // 没权限，引导用户前往权限设置页面
        Column(modifier = Modifier.fillMaxSize() ,
            horizontalAlignment = Alignment.CenterHorizontally,// 水平居中
            verticalArrangement = Arrangement.Center// 垂直居中
            ) {
            切角按钮(onClick = { 发起权限申请(context) },
                modifier = Modifier.size(248.dp,48.dp),
                shape = CutCornerShape(10.dp)// 切角形状
            ) { Text(text = "还请授权",modifier=Modifier,Color.DarkGray, fontSize = 20.sp)}
        }
    }
}
@Composable
fun 主界面() {
    Mindustry设计器Theme{
        val 系统UI控制器 = rememberSystemUiController()
        val 深色模式 = isSystemInDarkTheme()
        // 设置状态栏代码
        SideEffect() {
            系统UI控制器.setStatusBarColor(// 设置状态栏颜色
                color = if (深色模式) Color.Black else Color.LightGray,
                darkIcons = !深色模式 // 是否启用深色图标(深色模式不启用)
            )
        }

        Mod文件夹检查()
        val mod打包器:ModPack = ModPack()
        mod打包器.打包(Mod文件夹)
        Scaffold(// 脚手架布局, 比较适合作为底布局
            modifier = Modifier
                .fillMaxSize(), //填充最大化
            contentColor = if (深色模式) Color.LightGray else Color.DarkGray, //内容颜色(字体之类的)
            containerColor = if (深色模式) Color.DarkGray else Color.White //背景颜色
        ) { innerPadding -> // Scaffold提供的 内边距,这样在各平台上兼容可以避免布局被状态栏等遮挡.
            Box(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
            ) {
                Column() {
                    Mod对象列表()
                }
            }
        }
    }
}


// 招呼函数
@Composable
fun Mod对象列表() {
    val context = LocalContext.current //返回最近的上下文
    var items:MutableList<List<String>> = 遍历目录(Mod文件夹)
    Log.d("My",items.toString())
    LazyColumn(
        modifier = Modifier.fillMaxSize(), // 填满整个屏幕
        verticalArrangement = Arrangement.spacedBy(3.dp) // 设置列表项之间的间距
    ) {
        item { Text("Mod文件夹: ${Mod文件夹.path}", fontSize = 15.sp) }
        items(items) { item -> // 遍历数据列表
            Row(Modifier
                .clickable { toast(context,item[2]) }
                .border(4.dp, color = Color.LightGray, shape = CutCornerShape(8.dp))
                .clip(shape = CutCornerShape(8.dp))// 修剪内容, 这样就不会出界了.
                .padding(8.dp)) {
                val 图标:ImageBitmap = when(item[1]){
                    "杂项" -> 读内部图片(context,"UI/message.png")
                    "单位" -> 读内部图片(context,"UI/dagger.png")
                    "方块" -> 读内部图片(context,"UI/copper-wall-large.png")
                    "液体" -> 读内部图片(context,"UI/liquid-water.png")
                    "物品" -> 读内部图片(context,"UI/item-surge-alloy.png")
                    else -> {读内部图片(context,"UI/item-surge-alloy.png")}
                }
                val 图标色:Color = when(item[1]){
                    "杂项" -> Color.LightGray
                    "单位" -> Color.Blue
                    "方块" -> Color.Yellow
                    "液体" -> 蔚蓝色
                    "物品" -> Color.Yellow
                    else -> {Color.White}
                }

                Image(bitmap = 图标,
                    contentDescription = null,// 内容描述, 没啥用, 填空.
                    contentScale = ContentScale.Fit,// 内容缩放
                    modifier = Modifier
                        .size(42.dp)
                        //.border(2.dp, color = Color.LightGray, shape = CutCornerShape(4.dp))
                        .clip(shape = CutCornerShape(8.dp))// 修剪内容, 这样就不会出界了.
                    //.background(图标底色)
                )
                Text(text = item[0], modifier = Modifier
                        .padding(8.dp),
                    fontSize = 15 .sp
                )
                Text(text =" ."+item[1], modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                    fontSize = 12.sp,
                    color = Color.LightGray
                )
            }
        }
    }
}
fun Mod文件夹检查() {
    // 检查mod文件夹目录是否存在
    if (!Mod文件夹.exists()) {// mod文件夹目录不存在
        Mod文件夹.mkdirs()// 创建文件夹及其所有必要的父目录
    }
    //mod配置文件检测
    val mod配置路径 = File(Mod文件夹, "/mod.json")
    // 检查 是否文件不存在或是目录(目录确实可以命名为mod.json这种名称)
    if (!mod配置路径.isFile())// 不存在就创建, 并写入必要代码
    // 如果不存在或为目录
    { 创建对象(mod配置路径) }
}
fun 发起权限申请(上下文: Context){
    // 如果不能访问外部存储目录, 则申请权限
    if (!Environment.isExternalStorageManager()) {
        // 编写意图, 让后实现意图 Intent()这个构造函数里面填的就是要实现的 官方意图常量
        val intent = Intent(ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)// 意图为 管理应用程序所有文件的访问权限
        intent.data = Uri.parse("package:${上下文.packageName}")
        上下文.startActivity(intent)// 启动活动, 实现意图!!!
        刚从权限设置里面回来 = true// 赋值标志位, 这样下一次返回应用 重新获得焦点() 方法就可以避免误认
    } else {
        Log输出("已授权")
    }
}




