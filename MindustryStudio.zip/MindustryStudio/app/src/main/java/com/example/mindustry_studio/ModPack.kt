package com.example.mindustry_studio

import android.util.Log
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ModPack {
    private val 打包对象组: MutableList<File> = mutableListOf(File(Mod文件夹, "/mod.json"))
    fun 添加打包对象(路径: File) {
        打包对象组.add(路径)
    }
    fun 打包(打包位置:File) {
        val mod名称: String = 读取外部对象文件(File(Mod文件夹,"/mod.json")).getString("mod名称") //!!表示绝对不为null
        val jarFile = File(打包位置, "$mod名称.jar")
        // 创建 ZipOutputStream
        val fos = FileOutputStream(jarFile)// 文件输出流
        val zos = ZipOutputStream(BufferedOutputStream(fos))// Zip(modJAR包)输出流
        try {
            for (file in 打包对象组) {
                if (file.exists()) {
                    val zipEntry = ZipEntry(file.path.取mod内路径())// 用指定的名称创建新的 zip 条目.
                    Log.d("My","已创建新zip条目: ${zipEntry.toString()}")
                    zos.putNextEntry(zipEntry)// 开始写入新的 ZIP 文件条目, 并将数据流定位到条目数据的起始位置.

                    // 读取文件内容, 让后进行翻译等修改（在内存中）
                    val 读取文本:String = 翻译对象(读取外部对象文件(file)).toString(3)

                    // 将修改后的内容写入 modJAR包
                    zos.write(读取文本.toByteArray())
                    zos.closeEntry()
                } else {
                    Log.d("My","文件不存在: ${file.path}")
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        } finally {
            zos.close()
            fos.close()
        }

    }
}
fun 翻译对象(对象:JSONObject):JSONObject {
    val 新对象:JSONObject = JSONObject()
    val 代码区:JSONObject = 获取代码区("mod配置")
    for (代码名 in 对象.keys()){
        // 将翻译后的代码添加到新对象中
        新对象.put(代码区.getJSONObject(代码名).getString("原名"),// 翻译键名
            对象[代码名]// 原封不动复制内容
        )
    }
    return 新对象
}













