package com.example.mindustry_studio

import android.content.Context
import android.graphics.BitmapFactory
import android.util.Log
import android.widget.Toast
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import org.json.JSONObject
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.FileReader
import java.io.FileWriter
import java.io.IOException
import java.io.InputStreamReader
import java.io.Reader
/*工具类, 防止主Activity太大冗赘*/

// 弹出提示
fun toast(context: Context,chan:CharSequence){
    Toast.makeText(context,chan, Toast.LENGTH_SHORT).show()
}
fun Log输出(内容: String){
    Log.d("my",内容)
}
// 封装函数本身就是一种乐趣, 追求效率无置可否, 但也别把用户手机当单片机了.
fun 读取外部json文件(file: File): String?{
    return 读取json的Reader(FileReader(file))
}
fun 读取内部json文件(context: Context, 内部json文件路径:String): String?{
    return 读取json的Reader(InputStreamReader(context.assets.open(内部json文件路径)))
}
/* 这个参数是需要一个Reader, 就是一个读取字符串的中间对象
    慢慢来, 对着InputStream对象找可以转换他为Reader的方法
    一般读取assets里面的文件, 先open成InputStream再用InputStreamReader()方法
    对正常外部才能出的文件直接FileReader(), 就可以直接获得Reader了*/
fun 读取json的Reader(reader参数: Reader): String? {
    val jsonString = StringBuilder()// 创建字符串操作器 这个方便处理文本
    try {// 处理文件的, 直接路径依赖就彳亍, 我上面把参数从String改成Reader就已经基本没问题了.
        BufferedReader(reader参数).use { reader ->
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                jsonString.append(line)
            }
        }
    } catch (e: IOException) {
        e.printStackTrace()
        return null
    }
    return jsonString.toString()
}
// 简单封装 写入文件不算太难, 也不太可能出错, 主要是优雅()
fun 写文件(内容:String, 路径: File,覆盖:Boolean = false){
    try {
        // 检查文件是否存在，如果不存在则创建
        if (!路径.exists()) {
            路径.parentFile?.mkdirs() // 创建父目录
            创建文件(路径) // 创建文件
        }
        // 使用 BufferedWriter 写入文件
        BufferedWriter(FileWriter(路径,!覆盖)).use { writer ->
            writer.write(内容)
            Log输出("写入成功, 内容: $内容")
        }
    } catch (e: IOException) {
        e.printStackTrace()
    }
}
fun 创建文件(文件路径: File){
    try {
        val created = 文件路径.createNewFile()
        if (created) {
            Log输出("文件创建成功: $文件路径")
        } else {
            Log输出( "文件已存在")
        }
    } catch (e: IOException) {
        e.printStackTrace()
    }
}
fun 创建对象(路径:File){
    创建文件(路径)// 创建mod.json文件

    val mod对象:JSONObject = JSONObject()
    val mod属性代码: JSONObject = 获取代码区("mod配置")
    val 必要代码 = 筛选代码(mod属性代码) {// 接收函数提供的代码参数, 并处理逻辑
            代码: JSONObject ->
        代码.getBoolean("必要")
    }
    for (代码名 in 必要代码){
        mod对象.put(代码名, mod属性代码.getJSONObject(代码名)["示例"])
    }
    写文件(mod对象.toString(3), 路径, true)
}

fun 获取代码区(区键名:String):JSONObject{
    return 代码表.getJSONObject(区键名)
}
fun 是必要代码(代码:JSONObject):Boolean{
    return 代码.getBoolean("必要")
}
//Array数组只读固定长度性能更好
/**
 * @param 代码区域: 需要筛选的代码区域
 * @param 筛选条件式 筛选所需的条件式, 需要满足整个条件式返回值为 Boolean 类型,
 * @param 代码 :JSONObject为遍历该代码区域 得到的每一个代码
 * @return 一个String类型的Array数组*/
fun 筛选代码(代码区域:JSONObject, 筛选条件式: (代码:JSONObject) -> Boolean):Array<String> {
    val 必要代码列表:MutableList<String> = mutableListOf()
    // 遍历代码区域的 所有代码.
    val keys = 代码区域.keys()
    while (keys.hasNext()) {// hasNext()有下一个, 如果迭代有更多代码, 则返回true
        val 键名 = keys.next()
        val 代码 = 代码区域[键名]
        // 检查值是否为 JSONObject.
        if (代码 is JSONObject) {
            // 检查代码的属性, 是否符合条件
            if (筛选条件式(代码)) {// 把代码的子代码 传递给匿名函数做参数.
                必要代码列表.add(键名)
            }
        }
    }
    return 必要代码列表.toTypedArray()
}
fun 读取外部对象文件(路径: File):JSONObject{
    return JSONObject(读取外部json文件(路径)!!)
}
fun String.取mod内路径():String{
    return removePrefix(Mod文件夹.path+"/")
}
fun 遍历目录(目录:File): MutableList<List<String>> {
    val 目录列表 = 目录.listFiles() // 获取目录中的所有文件和子目录

    var 对象列表: MutableList<List<String>> = mutableListOf()
    if (目录列表 != null) {
        for (file in 目录列表) {
            if (file.isDirectory) {
                遍历目录(file) // 递归遍历子目录
            } else {
                // 是文件判断是不是对象
                if (file.extension == "json") {
                    对象列表.add(listOf(file.name,"杂项",file.path))
                    Log输出(对象列表.toString())
                }
            }
        }
    }
    return 对象列表
}

fun 读取项目(){
}
fun 读内部图片(context:Context,内部路径: String):ImageBitmap{
    val bitmap = BitmapFactory.decodeStream(context.assets.open(内部路径)) // 将 InputStream 转换为 Bitmap
    return bitmap.asImageBitmap() // 将 Bitmap 转换为 ImageBitmap, 最后输出
}